from bokeh.plotting import figure, show, output_file
from bokeh.models import HoverTool
import pandas as pd
import yfinance as yf
import numpy as np

def run_simulation(ticker, num_days):
    data = yf.download(ticker)
    data = data.reset_index()

    # Calculate daily returns
    data['Return'] = data['Close'].pct_change()
    # Calculate mean and standard deviation of daily returns
    mean_return = data['Return'].mean()
    std_return = data['Return'].std()

    # Set the number of simulations and time period
    num_simulations = 1000

    # Generate random daily returns based on mean and standard deviation
    daily_returns = np.random.normal(mean_return, std_return, (num_days, num_simulations))
    # Create an empty array to store the simulated prices
    simulated_prices = np.zeros((num_days, num_simulations))
    # Set the initial price as the last known close price
    initial_price = data['Close'].iloc[-1]

    # Perform the Monte Carlo simulation
    for i in range(num_simulations):
        price = initial_price
        for j in range(num_days):
            price += price * daily_returns[j, i]
            simulated_prices[j, i] = price

    # Calculate the mean of the simulated prices for each day
    mean_simulated_prices = np.mean(simulated_prices, axis=1)

    # Get the dates for the next num_days
    last_date = data['Date'].iloc[-1]
    next_dates = pd.date_range(start=last_date + pd.DateOffset(days=1), periods=num_days, freq='D')

    # Example scoring system based on deviation from historical mean return
    historical_mean_return = data['Return'].mean()
    # Calculate deviation of each simulation from historical mean return
    deviations = np.abs(np.mean(daily_returns, axis=0) - historical_mean_return)
    # Assign scores inversely proportional to deviations
    scores = 1 / (1 + deviations)
    # Select the simulation with the highest score
    selected_simulation_index = np.argmax(scores)
    selected_simulation = simulated_prices[:, selected_simulation_index]

    # Create an interactive plot using Bokeh
    output_file("simulation_plot.html")  # Save the plot as an HTML file

    p = figure(title=f"Monte Carlo Simulation - Next {num_days} Days", x_axis_label='Date', y_axis_label='Selected Simulation Prices')
    p.line(next_dates, selected_simulation, legend_label="Selected Simulation", line_width=2)

    hover = HoverTool(tooltips=[("Date", "@x{%F}"), ("Price", "@y")], formatters={"@x": "datetime"})
    p.add_tools(hover)

    show(p)  # Display the plot

    return selected_simulation



