from django.contrib import admin
from django.urls import path
from model_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.predict, name='predict'),
    #path('result/', views.result_view, name='result'),
    #path('graph/', views.graph_view, name='graph'),
]