import pickle
from django.shortcuts import render
from model import run_simulation
import pandas as pd


def predict(request):
    metals = [
        {"name": "Steel", "ticker": "SLX"},
        {"name": "Aluminium", "ticker": "ALI=F"},
        {"name": "Copper", "ticker": "HG=F"},
        {"name": "Cast Iron", "ticker": "IRON"},
        {"name": "Magnesium", "ticker": "MAG=F"},
        {"name": "Titanium", "ticker": "TIE=F"},
        {"name": "Zinc", "ticker": "ZN=F"},
    ]

    if request.method == 'POST':
        try:
            metal_index = int(request.POST.get('metal'))
            num_days = int(request.POST.get('num_days'))

            selected_metal = metals[metal_index]
            ticker = selected_metal["ticker"]

            # Perform the Monte Carlo simulation
            result = run_simulation(ticker, num_days)

            # Prepare the result data for template rendering
            last_date = pd.Timestamp('today')
            next_dates = [last_date + pd.DateOffset(days=i) for i in range(1, num_days + 1)]
            result_data = [{'Date': date, 'Selected_Simulation_Price': price} for date, price in zip(next_dates, result)]

            # Pass the result data to the template
            context = {'result_data': result_data}
            return render(request, 'result.html', context)
        except Exception as e:
            error = str(e)
            return render(request, 'error.html', {'error': error})
    else:
        return render(request, 'index.html', {'metals': metals})
